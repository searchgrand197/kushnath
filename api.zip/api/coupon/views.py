from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from django.utils import timezone
from django.db.models import Q
from .models import SpecialCoupon, CouponForAll, OneTimeCoupon
from .serializers import (
    SpecialCouponSerializer, 
    CouponForAllSerializer, 
    OneTimeCouponSerializer,
    CouponValidationSerializer,
    CouponResponseSerializer
)

@api_view(['GET'])
@permission_classes([AllowAny])
def list_coupons(request):
    """List all active coupons"""
    try:
        current_time = timezone.now()
        
        # Get active coupons for all users
        coupons_for_all = CouponForAll.objects.filter(
            active=True,
            valid_from__lte=current_time,
            valid_to__gte=current_time
        )
        
        # Get active special coupons
        special_coupons = SpecialCoupon.objects.filter(active=True)
        
        # Get active one-time coupons
        one_time_coupons = OneTimeCoupon.objects.filter(
            active=True,
            valid_from__lte=current_time,
            valid_to__gte=current_time
        )
        
        # Serialize the data
        data = {
            'coupons_for_all': CouponForAllSerializer(coupons_for_all, many=True).data,
            'special_coupons': SpecialCouponSerializer(special_coupons, many=True).data,
            'one_time_coupons': OneTimeCouponSerializer(one_time_coupons, many=True).data
        }
        
        return Response(data, status=status.HTTP_200_OK)
        
    except Exception as e:
        return Response(
            {'error': f'Failed to fetch coupons: {str(e)}'}, 
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

@api_view(['POST'])
@permission_classes([AllowAny])
def validate_coupon(request):
    """Validate a coupon code"""
    try:
        serializer = CouponValidationSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        code = serializer.validated_data['code'].upper().strip()
        cart_total = serializer.validated_data['cart_total']
        user_id = serializer.validated_data.get('user_id')
        
        # Check if coupon exists and is valid
        coupon = None
        coupon_type = None
        
        # Check SpecialCoupon first
        try:
            special_coupon = SpecialCoupon.objects.get(code__iexact=code, active=True)
            if user_id and special_coupon.coupon_for.filter(id=user_id).exists():
                coupon = special_coupon
                coupon_type = 'special'
        except SpecialCoupon.DoesNotExist:
            pass
        
        # Check CouponForAll if no special coupon found
        if not coupon:
            try:
                coupon_for_all = CouponForAll.objects.get(
                    code__iexact=code, 
                    active=True,
                    valid_from__lte=timezone.now(),
                    valid_to__gte=timezone.now()
                )
                coupon = coupon_for_all
                coupon_type = 'for_all'
            except CouponForAll.DoesNotExist:
                pass
        
        # Check OneTimeCoupon if no other coupon found
        if not coupon:
            try:
                one_time_coupon = OneTimeCoupon.objects.get(
                    code__iexact=code, 
                    active=True,
                    valid_from__lte=timezone.now(),
                    valid_to__gte=timezone.now()
                )
                # Check if user has already used this coupon
                if user_id and one_time_coupon.used_by.filter(id=user_id).exists():
                    return Response({
                        'valid': False,
                        'message': 'This coupon has already been used by you.'
                    }, status=status.HTTP_400_BAD_REQUEST)
                
                coupon = one_time_coupon
                coupon_type = 'one_time'
            except OneTimeCoupon.DoesNotExist:
                pass
        
        if not coupon:
            return Response({
                'valid': False,
                'message': 'Invalid or expired coupon code.'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        # Calculate discount amount
        if coupon.discount_type == 'percent':
            discount_amount = (cart_total * coupon.discount) / 100
        else:
            discount_amount = coupon.discount
        
        # Ensure discount doesn't exceed cart total
        if discount_amount > cart_total:
            discount_amount = cart_total
        
        response_data = {
            'valid': True,
            'code': coupon.code,
            'discount_type': coupon.discount_type,
            'discount': coupon.discount,
            'description': coupon.description or '',
            'discount_amount': round(discount_amount, 2),
            'message': f'Coupon applied successfully! You save ₹{discount_amount:.2f}'
        }
        
        return Response(response_data, status=status.HTTP_200_OK)
        
    except Exception as e:
        return Response(
            {'error': f'Failed to validate coupon: {str(e)}'}, 
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

@api_view(['POST'])
@permission_classes([AllowAny])
def mark_coupon_used(request):
    """Mark a one-time coupon as used by a user"""
    try:
        code = request.data.get('code', '').upper().strip()
        user_id = request.data.get('user_id')
        
        if not code or not user_id:
            return Response(
                {'error': 'Both code and user_id are required'}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            coupon = OneTimeCoupon.objects.get(code__iexact=code, active=True)
            coupon.used_by.add(user_id)
            return Response({'message': 'Coupon marked as used'}, status=status.HTTP_200_OK)
        except OneTimeCoupon.DoesNotExist:
            return Response(
                {'error': 'Coupon not found'}, 
                status=status.HTTP_404_NOT_FOUND
            )
            
    except Exception as e:
        return Response(
            {'error': f'Failed to mark coupon as used: {str(e)}'}, 
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )
