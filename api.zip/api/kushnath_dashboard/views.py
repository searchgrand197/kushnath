from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
from django.conf import settings
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
import os

def serve_react_app(request, path=''):
    """
    Serve the React app for all routes except API routes
    """
    # Don't serve React app for API routes
    if path.startswith('api/'):
        return HttpResponse("API route not found", status=404)
    
    # Don't serve React app for asset files (these are handled by URL patterns)
    if path.startswith('assets/'):
        return HttpResponse("Asset not found", status=404)
    
    # Serve the main React app index.html for all other routes
    try:
        return render(request, 'build/index.html')
    except:
        # Fallback if template doesn't exist
        index_path = os.path.join(settings.BASE_DIR, 'build', 'index.html')
        if os.path.exists(index_path):
            with open(index_path, 'r', encoding='utf-8') as f:
                content = f.read()
            return HttpResponse(content, content_type='text/html')
        else:
            return HttpResponse("React app not found. Please build the frontend first.", status=404)

@csrf_exempt
@require_http_methods(["GET", "POST", "OPTIONS"])
def cors_test_view(request):
    """
    Test view to verify CORS is working properly
    """
    if request.method == "OPTIONS":
        # Handle preflight request
        response = HttpResponse()
        response["Access-Control-Allow-Origin"] = "*"
        response["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
        response["Access-Control-Allow-Headers"] = "Content-Type, Authorization"
        return response
    
    return JsonResponse({
        "message": "CORS test successful",
        "method": request.method,
        "origin": request.META.get('HTTP_ORIGIN', 'No origin'),
        "headers": dict(request.headers)
    })
