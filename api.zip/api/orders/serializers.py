from rest_framework import serializers
from .models import Order, OrderItem, OrderStatusHistory
from customer.models import Customer, CustomerAddress
from dashboard.models import Product
from cart.models import CartDetails, CartItem
from decimal import Decimal
import requests
import json

class OrderItemSerializer(serializers.ModelSerializer):
    product_name = serializers.CharField(source='product.name', read_only=True)
    product_image = serializers.SerializerMethodField()
    
    class Meta:
        model = OrderItem
        fields = ['id', 'product', 'product_name', 'product_image', 'quantity', 'unit_price', 'total_price']
        read_only_fields = ['unit_price', 'total_price']
    
    def get_product_image(self, obj):
        if obj.product.images.exists():
            return self.context['request'].build_absolute_uri(obj.product.images.first().image.url)
        return None

class OrderStatusHistorySerializer(serializers.ModelSerializer):
    changed_by_name = serializers.CharField(source='changed_by.username', read_only=True)
    
    class Meta:
        model = OrderStatusHistory
        fields = ['id', 'status', 'changed_by', 'changed_by_name', 'changed_at', 'notes']
        read_only_fields = ['changed_at']

class OrderSerializer(serializers.ModelSerializer):
    items = OrderItemSerializer(many=True, read_only=True)
    status_history = OrderStatusHistorySerializer(many=True, read_only=True)
    customer_name = serializers.CharField(source='customer.name', read_only=True)
    customer_email = serializers.CharField(source='customer.email', read_only=True)
    
    class Meta:
        model = Order
        fields = [
            'id', 'order_id', 'customer', 'customer_name', 'customer_email', 'customer_mobile',
            'status', 'payment_status', 'payment_method', 'delivery_address', 'delivery_pincode',
            'delivery_city', 'delivery_state', 'delivery_country', 'recipient_name', 'recipient_phone',
            'subtotal', 'shipping_cost', 'discount_amount', 'total_amount', 'is_deliverable',
            'shipment_created', 'tracking_number', 'created_at', 'updated_at', 'delivered_at',
            'cancelled_at', 'notes', 'cancellation_reason', 'items', 'status_history'
        ]
        read_only_fields = [
            'order_id', 'subtotal', 'shipping_cost', 'discount_amount', 'total_amount',
            'is_deliverable', 'shipment_created', 'tracking_number', 'created_at', 'updated_at',
            'delivered_at', 'cancelled_at'
        ]

class CreateOrderItemSerializer(serializers.Serializer):
    product_id = serializers.IntegerField()
    quantity = serializers.IntegerField(min_value=1)

class CreateOrderSerializer(serializers.ModelSerializer):
    # Cart-based order (optional)
    cart_id = serializers.IntegerField(write_only=True, required=False)
    
    # Direct order creation (alternative to cart)
    order_items = CreateOrderItemSerializer(many=True, required=False)
    
    # Delivery info (required)
    delivery_pincode = serializers.CharField()
    delivery_city = serializers.CharField()
    delivery_state = serializers.CharField()
    delivery_country = serializers.CharField(default='India')
    delivery_address_text = serializers.CharField()
    
    # Required fields
    payment_method = serializers.ChoiceField(choices=Order.PAYMENT_METHOD_CHOICES)
    
    class Meta:
        model = Order
        fields = [
            'customer_mobile', 'cart_id', 'payment_method',
            'recipient_name', 'recipient_phone', 'notes',
            'delivery_pincode', 'delivery_city', 'delivery_state', 
            'delivery_country', 'delivery_address_text', 'order_items'
        ]
    
    def validate(self, data):
        cart_id = data.get('cart_id')
        order_items = data.get('order_items', [])
        
        # Must have either cart_id OR order_items
        if not cart_id and not order_items:
            raise serializers.ValidationError("Either cart_id or order_items must be provided")
        
        if cart_id and order_items:
            raise serializers.ValidationError("Cannot use both cart_id and order_items")
        
        return data
    
    def validate_customer_mobile(self, value):
        try:
            customer = Customer.objects.get(mobiles__mobile=value)
            return value
        except Customer.DoesNotExist:
            raise serializers.ValidationError("No customer found with this mobile number.")
    
    def validate(self, data):
        cart_id = data.get('cart_id')
        delivery_address_id = data.get('delivery_address_id')
        delivery_pincode = data.get('delivery_pincode')
        order_items = data.get('order_items', [])
        
        # If no cart_id provided, delivery info is required
        if not cart_id:
            if not delivery_pincode:
                raise serializers.ValidationError("delivery_pincode is required when not using cart_id")
            if not data.get('delivery_city'):
                raise serializers.ValidationError("delivery_city is required when not using cart_id")
            if not data.get('delivery_state'):
                raise serializers.ValidationError("delivery_state is required when not using cart_id")
            if not order_items:
                raise serializers.ValidationError("order_items is required when not using cart_id")
        
        # Validate cart if provided
        if cart_id:
            try:
                cart = CartDetails.objects.get(id=cart_id)
                if not cart.items.exists():
                    raise serializers.ValidationError("Cart is empty.")
            except CartDetails.DoesNotExist:
                raise serializers.ValidationError("Cart not found.")
        
        # Validate delivery address if provided
        if delivery_address_id:
            try:
                address = CustomerAddress.objects.get(id=delivery_address_id)
            except CustomerAddress.DoesNotExist:
                raise serializers.ValidationError("Delivery address not found.")
        
        # Validate order items if provided
        if order_items:
            for item in order_items:
                try:
                    product = Product.objects.get(id=item['product_id'])
                    if not product.available:
                        raise serializers.ValidationError(f"Product {product.name} is not available")
                    if product.stock < item['quantity']:
                        raise serializers.ValidationError(f"Insufficient stock for {product.name}")
                except Product.DoesNotExist:
                    raise serializers.ValidationError(f"Product with id {item['product_id']} not found")
        
        return data
    
    def check_delivery_pincode(self, pincode):
        try:
            url = "https://staging-express.delhivery.com/api/dc/fetch/serviceability/pincode/"
            params = {
                'token': '0368e03c66b1fc26848d7d4bed4798c45de2b3cf',
                'filter_codes': pincode
            }
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {'delivery_codes': [{'postal_code': {'pin': pincode, 'deliverable': True}}]}
    
    def create(self, validated_data):
        cart_id = validated_data.pop('cart_id', None)
        delivery_address_id = validated_data.pop('delivery_address_id', None)
        order_items_data = validated_data.pop('order_items', [])
        
        # Get customer
        customer = Customer.objects.get(mobiles__mobile=validated_data['customer_mobile'])
        
        # Handle delivery address
        delivery_address = None
        delivery_pincode = None
        
        if delivery_address_id:
            delivery_address = CustomerAddress.objects.get(id=delivery_address_id)
            delivery_pincode = delivery_address.pincode
            delivery_city = delivery_address.city
            delivery_state = delivery_address.state
            delivery_country = delivery_address.country
        else:
            delivery_pincode = validated_data['delivery_pincode']
            delivery_city = validated_data['delivery_city']
            delivery_state = validated_data['delivery_state']
            delivery_country = validated_data.get('delivery_country', 'India')
        
        # Check delivery pincode
        delivery_api_response = self.check_delivery_pincode(delivery_pincode)
        is_deliverable = False
        
        if delivery_api_response.get('delivery_codes'):
            for code in delivery_api_response['delivery_codes']:
                if code.get('postal_code', {}).get('deliverable', False):
                    is_deliverable = True
                    break
        
        if not is_deliverable:
            raise serializers.ValidationError("Delivery not available for this pincode.")
        
        # Calculate totals
        subtotal = Decimal('0.00')
        
        if cart_id:
            # Calculate from cart
            cart = CartDetails.objects.get(id=cart_id)
            for cart_item in cart.items.all():
                product = cart_item.product
                price = product.price
                if product.discount > 0:
                    if product.discount_type == 'percent':
                        discount_amount = (price * product.discount) / 100
                    else:
                        discount_amount = product.discount
                    price = price - discount_amount
                subtotal += price * cart_item.quantity
        else:
            # Calculate from direct order items
            for item_data in order_items_data:
                product = Product.objects.get(id=item_data['product_id'])
                price = product.price
                if product.discount > 0:
                    if product.discount_type == 'percent':
                        discount_amount = (price * product.discount) / 100
                    else:
                        discount_amount = product.discount
                    price = price - discount_amount
                subtotal += price * item_data['quantity']
        
        # Create order
        order = Order.objects.create(
            customer=customer,
            customer_mobile=validated_data['customer_mobile'],
            payment_method=validated_data['payment_method'],
            delivery_address=delivery_address,
            delivery_pincode=delivery_pincode,
            delivery_city=delivery_city,
            delivery_state=delivery_state,
            delivery_country=delivery_country,
            recipient_name=validated_data.get('recipient_name', customer.name),
            recipient_phone=validated_data.get('recipient_phone', validated_data['customer_mobile']),
            subtotal=subtotal,
            total_amount=subtotal,
            is_deliverable=is_deliverable,
            delivery_api_response=delivery_api_response,
            notes=validated_data.get('notes', '')
        )
        
        # Create order items
        if cart_id:
            # Create from cart
            cart = CartDetails.objects.get(id=cart_id)
            for cart_item in cart.items.all():
                product = cart_item.product
                price = product.price
                if product.discount > 0:
                    if product.discount_type == 'percent':
                        discount_amount = (price * product.discount) / 100
                    else:
                        discount_amount = product.discount
                    price = price - discount_amount
                
                OrderItem.objects.create(
                    order=order,
                    product=product,
                    quantity=cart_item.quantity,
                    unit_price=price,
                    total_price=price * cart_item.quantity
                )
            
            # Clear cart
            cart.items.all().delete()
        else:
            # Create from direct order items
            for item_data in order_items_data:
                product = Product.objects.get(id=item_data['product_id'])
                price = product.price
                if product.discount > 0:
                    if product.discount_type == 'percent':
                        discount_amount = (price * product.discount) / 100
                    else:
                        discount_amount = product.discount
                    price = price - discount_amount
                
                OrderItem.objects.create(
                    order=order,
                    product=product,
                    quantity=item_data['quantity'],
                    unit_price=price,
                    total_price=price * item_data['quantity']
                )
        
        # Create initial status history
        OrderStatusHistory.objects.create(
            order=order,
            status='pending',
            notes='Order created'
        )
        
        return order

class UpdateOrderStatusSerializer(serializers.ModelSerializer):
    new_status = serializers.ChoiceField(choices=Order.ORDER_STATUS_CHOICES, write_only=True)
    notes = serializers.CharField(required=False, allow_blank=True)
    
    class Meta:
        model = Order
        fields = ['new_status', 'notes']
    
    def update(self, instance, validated_data):
        new_status = validated_data.pop('new_status')
        notes = validated_data.get('notes', '')
        
        # Update order status
        instance.status = new_status
        
        # Handle specific status changes
        if new_status == 'delivered':
            from django.utils import timezone
            instance.delivered_at = timezone.now()
            instance.payment_status = 'paid'
        elif new_status == 'cancelled':
            from django.utils import timezone
            instance.cancelled_at = timezone.now()
            if instance.payment_method == 'prepaid':
                instance.payment_status = 'refunded'
        
        instance.save()
        
        # Create status history
        OrderStatusHistory.objects.create(
            order=instance,
            status=new_status,
            changed_by=self.context['request'].user,
            notes=notes
        )
        
        return instance

class CreateShipmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Order
        fields = ['id']
    
    def update(self, instance, validated_data):
        if instance.shipment_created:
            raise serializers.ValidationError("Shipment already created for this order.")
        
        if instance.status not in ['confirmed', 'processing']:
            raise serializers.ValidationError("Order must be confirmed or processing to create shipment.")
        
        # Create shipment using Delhivery API
        try:
            url = "https://staging-express.delhivery.com/api/cmu/create.json"
            headers = {
                'Accept': 'application/json',
                'Authorization': 'Token 0368e03c66b1fc26848d7d4bed4798c45de2b3cf',
                'Content-Type': 'application/json'
            }
            
            # Prepare shipment data
            shipment_data = {
                "shipments": [{
                    "name": instance.recipient_name,
                    "add": instance.delivery_address.address if instance.delivery_address else "",
                    "pin": instance.delivery_pincode,
                    "city": instance.delivery_city,
                    "state": instance.delivery_state,
                    "country": instance.delivery_country,
                    "phone": instance.recipient_phone,
                    "order": instance.order_id,
                    "payment_mode": "Prepaid" if instance.payment_method == 'prepaid' else "COD",
                    "return_pin": "",
                    "return_city": "",
                    "return_phone": "",
                    "return_add": "",
                    "return_state": "",
                    "return_country": "",
                    "products_desc": ", ".join([f"{item.product.name} x {item.quantity}" for item in instance.items.all()]),
                    "hsn_code": "",
                    "cod_amount": str(instance.total_amount) if instance.payment_method == 'cod' else "",
                    "order_date": instance.created_at.strftime("%Y-%m-%d"),
                    "total_amount": str(instance.total_amount),
                    "seller_add": "Kushnath Ayurveda",
                    "seller_name": "Kushnath Ayurveda",
                    "seller_inv": instance.order_id,
                    "quantity": str(sum([item.quantity for item in instance.items.all()])),
                    "waybill": "",
                    "shipment_width": "100",
                    "shipment_height": "100",
                    "weight": "1",
                    "shipping_mode": "Surface",
                    "address_type": "Home"
                }],
                "pickup_location": {
                    "name": "Kushnath Ayurveda Warehouse"
                }
            }
            
            response = requests.post(
                url,
                headers=headers,
                data=f"format=json&data={json.dumps(shipment_data)}",
                timeout=30
            )
            response.raise_for_status()
            
            shipment_response = response.json()
            
            # Update order with shipment details
            instance.shipment_created = True
            instance.shipment_details = shipment_response
            instance.status = 'shipped'
            
            # Extract tracking number if available
            if shipment_response.get('packages'):
                for package in shipment_response['packages']:
                    if package.get('waybill'):
                        instance.tracking_number = package['waybill']
                        break
            
            instance.save()
            
            # Create status history
            OrderStatusHistory.objects.create(
                order=instance,
                status='shipped',
                changed_by=self.context['request'].user,
                notes=f"Shipment created. Response: {shipment_response}"
            )
            
        except Exception as e:
            raise serializers.ValidationError(f"Failed to create shipment: {str(e)}")
        
        return instance 