from django.contrib import admin
from django import forms
from django.utils.html import format_html
from django.urls import reverse
from .models import Product, ProductImage, Category, Tag, Benefit, Comment, Reply, PERCENT, PickupLocation, ReturnDetails, OrderDashboard, RazorpayOrder, CustomerOrder, OrderItem, PaymentTransaction, Company

class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = '__all__'
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.instance and self.instance.discount_type == PERCENT:
            self.fields['discount'].widget = forms.NumberInput(attrs={'min': 0, 'max': 100})

class ProductImageInline(admin.TabularInline):
    model = ProductImage
    extra = 1

class ProductImageAdmin(admin.ModelAdmin):
    list_display = ('product', 'image', 'get_image_preview')
    list_filter = ('product__category',)
    search_fields = ('product__name',)
    
    def get_image_preview(self, obj):
        if obj.image:
            return format_html('<img src="{}" style="max-height: 50px; max-width: 50px;" />', obj.image.url)
        return "No Image"
    get_image_preview.short_description = 'Preview'

class CommentInline(admin.TabularInline):
    model = Comment
    extra = 0

class ReplyInline(admin.TabularInline):
    model = Reply
    extra = 1

class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'description')
    search_fields = ('name', 'description')

class ProductAdmin(admin.ModelAdmin):
    form = ProductForm
    inlines = [ProductImageInline, CommentInline]
    filter_horizontal = ('tags', 'benefits')

class TagAdmin(admin.ModelAdmin):
    list_display = ('name',)
    search_fields = ('name',)

class BenefitAdmin(admin.ModelAdmin):
    list_display = ('name',)
    search_fields = ('name',)

class CommentAdmin(admin.ModelAdmin):
    inlines = [ReplyInline]

@admin.register(RazorpayOrder)
class RazorpayOrderAdmin(admin.ModelAdmin):
    list_display = ('order_id', 'amount', 'currency', 'status', 'created_at')
    list_filter = ('status', 'currency', 'created_at')
    search_fields = ('order_id', 'receipt')
    readonly_fields = ('order_id', 'created_at', 'updated_at')

# New Order Admin Classes
class OrderItemInline(admin.TabularInline):
    model = OrderItem
    extra = 0
    readonly_fields = ('total_price',)

class PaymentTransactionInline(admin.TabularInline):
    model = PaymentTransaction
    extra = 0
    readonly_fields = ('transaction_id', 'created_at', 'updated_at')

@admin.register(CustomerOrder)
class CustomerOrderAdmin(admin.ModelAdmin):
    list_display = ('order_number', 'customer_name', 'payment_method', 'payment_status', 'order_status', 'final_total', 'order_date', 'dashboard_link')
    list_filter = ('payment_method', 'payment_status', 'order_status', 'order_date')
    search_fields = ('order_number', 'customer_name', 'customer_email', 'customer_phone')
    readonly_fields = ('order_number', 'order_date', 'created_at', 'updated_at')
    inlines = [OrderItemInline, PaymentTransactionInline]
    
    def dashboard_link(self, obj):
        """Add a link to the professional dashboard"""
        url = reverse('order-dashboard')
        return format_html('<a href="{}" target="_blank" class="button">📊 View Dashboard</a>', url)
    dashboard_link.short_description = 'Dashboard'
    
    fieldsets = (
        ('Order Information', {
            'fields': ('order_number', 'order_date', 'order_status')
        }),
        ('Customer Information', {
            'fields': ('customer_name', 'customer_email', 'customer_phone')
        }),
        ('Delivery Information', {
            'fields': ('delivery_address', 'delivery_city', 'delivery_state', 'delivery_pincode', 'delivery_country')
        }),
        ('Payment Information', {
            'fields': ('payment_method', 'payment_status', 'payment_date')
        }),
        ('Amount Information', {
            'fields': ('subtotal', 'shipping_cost', 'total_savings', 'final_total')
        }),
        ('Razorpay Information', {
            'fields': ('razorpay_order_id', 'razorpay_payment_id', 'razorpay_signature'),
            'classes': ('collapse',)
        }),
        ('Additional Information', {
            'fields': ('notes', 'created_at', 'updated_at')
        })
    )

@admin.register(OrderItem)
class OrderItemAdmin(admin.ModelAdmin):
    list_display = ('order', 'product_name', 'quantity', 'unit_price', 'total_price')
    list_filter = ('order__order_status', 'order__payment_method')
    search_fields = ('product_name', 'order__order_number')
    readonly_fields = ('total_price',)

@admin.register(PaymentTransaction)
class PaymentTransactionAdmin(admin.ModelAdmin):
    list_display = ('transaction_id', 'order', 'amount', 'currency', 'status', 'payment_method', 'created_at')
    list_filter = ('status', 'payment_method', 'currency', 'created_at')
    search_fields = ('transaction_id', 'order__order_number')
    readonly_fields = ('transaction_id', 'created_at', 'updated_at')

@admin.register(Company)
class CompanyAdmin(admin.ModelAdmin):
    list_display = ['name', 'tagline', 'phone', 'email', 'created_at']
    readonly_fields = ['created_at', 'updated_at']
    fieldsets = (
        ('Basic Information', {
            'fields': ('name', 'tagline', 'description')
        }),
        ('Contact Information', {
            'fields': ('address', 'phone', 'email', 'website')
        }),
        ('Logo', {
            'fields': ('logo',),
            'description': 'Upload your company logo. Recommended: PNG with transparent background, 200x200px to 400x400px'
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        })
    )
    
    def has_add_permission(self, request):
        # Only allow one company record
        return not Company.objects.exists()
    
    def has_delete_permission(self, request, obj=None):
        # Prevent deletion of company record
        return False

# Register your models here.
admin.site.register(Product, ProductAdmin)
admin.site.register(ProductImage, ProductImageAdmin)
admin.site.register(Category, CategoryAdmin)
admin.site.register(Tag, TagAdmin)
admin.site.register(Benefit, BenefitAdmin)
admin.site.register(Comment, CommentAdmin)
admin.site.register(Reply)
admin.site.register(PickupLocation)
admin.site.register(ReturnDetails)
admin.site.register(OrderDashboard)
