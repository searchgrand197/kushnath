from rest_framework import serializers
from .models import Category, Tag, Benefit, Product, ProductImage, RazorpayOrder, CustomerOrder, OrderItem, PaymentTransaction, Company

class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ['id', 'name', 'image', 'description']

class TagSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tag
        fields = ['id', 'name']

class BenefitSerializer(serializers.ModelSerializer):
    class Meta:
        model = Benefit
        fields = ['id', 'name']

class ProductImageSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductImage
        fields = ['id', 'image']

class ProductSerializer(serializers.ModelSerializer):
    category = CategorySerializer(read_only=True)
    category_id = serializers.PrimaryKeyRelatedField(
        queryset=Category.objects.all(),
        source='category',
        write_only=True
    )
    tags = TagSerializer(many=True, read_only=True)
    tag_ids = serializers.ListField(
        child=serializers.IntegerField(),
        write_only=True,
        required=False
    )
    benefits = BenefitSerializer(many=True, read_only=True)
    benefit_ids = serializers.ListField(
        child=serializers.IntegerField(),
        write_only=True,
        required=False
    )
    images = ProductImageSerializer(many=True, read_only=True)

    class Meta:
        model = Product
        fields = [
            'id', 'name', 'quantity', 'total_rating', 'category', 'category_id', 'sku',
            'tags', 'tag_ids', 'benefits', 'benefit_ids', 'stock', 'price', 'discount_type',
            'discount', 'description', 'weight', 'length', 'breadth',
            'height', 'available', 'images'
        ]

    def create(self, validated_data):
        tag_ids = validated_data.pop('tag_ids', [])
        benefit_ids = validated_data.pop('benefit_ids', [])
        
        product = Product.objects.create(**validated_data)
        
        if tag_ids:
            tags = Tag.objects.filter(id__in=tag_ids)
            product.tags.set(tags)
        
        if benefit_ids:
            benefits = Benefit.objects.filter(id__in=benefit_ids)
            product.benefits.set(benefits)
            
        return product

    def update(self, instance, validated_data):
        tag_ids = validated_data.pop('tag_ids', None)
        benefit_ids = validated_data.pop('benefit_ids', None)
        
        # Update other fields
        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()
        
        # Update tags if provided
        if tag_ids is not None:
            tags = Tag.objects.filter(id__in=tag_ids)
            instance.tags.set(tags)
        
        # Update benefits if provided
        if benefit_ids is not None:
            benefits = Benefit.objects.filter(id__in=benefit_ids)
            instance.benefits.set(benefits)
            
        return instance 

class RazorpayOrderSerializer(serializers.ModelSerializer):
    class Meta:
        model = RazorpayOrder
        fields = '__all__'

# New Order Serializers
class OrderItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = OrderItem
        fields = [
            'id', 'product_id', 'product_name', 'product_image', 'quantity', 
            'unit_price', 'total_price', 'discount_price', 'original_price'
        ]

class PaymentTransactionSerializer(serializers.ModelSerializer):
    class Meta:
        model = PaymentTransaction
        fields = [
            'id', 'transaction_id', 'amount', 'currency', 'status', 
            'payment_method', 'gateway_response', 'created_at'
        ]

class CustomerOrderSerializer(serializers.ModelSerializer):
    items = OrderItemSerializer(many=True, read_only=True)
    transactions = PaymentTransactionSerializer(many=True, read_only=True)
    
    class Meta:
        model = CustomerOrder
        fields = [
            'id', 'order_number', 'order_date', 'order_status',
            'customer_name', 'customer_email', 'customer_phone',
            'delivery_address', 'delivery_city', 'delivery_state', 
            'delivery_pincode', 'delivery_country',
            'payment_method', 'payment_status', 'payment_date',
            'subtotal', 'shipping_cost', 'total_savings', 'final_total',
            'razorpay_order_id', 'razorpay_payment_id', 'razorpay_signature',
            'notes', 'created_at', 'updated_at', 'items', 'transactions'
        ]
        read_only_fields = ['order_number', 'order_date', 'created_at', 'updated_at']

class CreateOrderSerializer(serializers.ModelSerializer):
    items = serializers.ListField(
        child=serializers.DictField(),
        write_only=True
    )
    
    class Meta:
        model = CustomerOrder
        fields = [
            'customer_name', 'customer_email', 'customer_phone',
            'delivery_address', 'delivery_city', 'delivery_state', 
            'delivery_pincode', 'delivery_country',
            'payment_method', 'subtotal', 'shipping_cost', 'total_savings', 
            'final_total', 'notes', 'items'
        ]
    
    def create(self, validated_data):
        items_data = validated_data.pop('items', [])
        
        # Create the order first
        order = CustomerOrder.objects.create(**validated_data)
        
        # Create order items
        for item_data in items_data:
            OrderItem.objects.create(
                order=order,
                product_id=item_data.get('id'),
                product_name=item_data.get('name'),
                product_image=item_data.get('image'),
                quantity=item_data.get('quantity'),
                unit_price=item_data.get('discountPrice', item_data.get('price')),
                discount_price=item_data.get('discountPrice'),
                original_price=item_data.get('product_price', item_data.get('price'))
            )
        
        # Create initial payment transaction AFTER order is saved
        PaymentTransaction.objects.create(
            order=order,
            transaction_id=f"TXN{order.order_number}",
            amount=order.final_total,
            currency='INR',
            status='pending',
            payment_method=order.payment_method
        )
        
        return order

class UpdatePaymentStatusSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomerOrder
        fields = ['payment_status', 'payment_date', 'razorpay_payment_id', 'razorpay_signature'] 

class CompanySerializer(serializers.ModelSerializer):
    class Meta:
        model = Company
        fields = '__all__' 