from django.shortcuts import render
from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.decorators import api_view, permission_classes
from .models import Category, Tag, Benefit, Product, ProductImage, RazorpayOrder
from .serializers import (
    CategorySerializer, TagSerializer, BenefitSerializer,
    ProductSerializer, ProductImageSerializer, RazorpayOrderSerializer
)
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
import json
import random
import requests
import razorpay
import hashlib
import hmac
from .models import PickupLocation, ReturnDetails, OrderDashboard
from django.views.decorators.http import require_POST
from datetime import datetime
from .serializers import CreateOrderSerializer, CustomerOrderSerializer, UpdatePaymentStatusSerializer
from .models import CustomerOrder
from .models import Company
from .serializers import CompanySerializer
from django.db.models import Q
from django.conf import settings

# Razorpay configuration from Django settings
RAZORPAY_KEY_ID = getattr(settings, 'RAZORPAY_KEY_ID', 'rzp_test_Q79E2maKMiRH3M')
RAZORPAY_KEY_SECRET = getattr(settings, 'RAZORPAY_KEY_SECRET', 'kP0dd2BxoCc0CjxDrsBO0hMn')
RAZORPAY_MODE = getattr(settings, 'RAZORPAY_MODE', 'test')

# Initialize Razorpay client with settings configuration
razorpay_client = razorpay.Client(auth=(RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET))

# Create your views here.

class CategoryListView(generics.ListAPIView):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    permission_classes = [AllowAny]

class CategoryDetailView(generics.RetrieveAPIView):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    permission_classes = [AllowAny]

class TagListView(generics.ListCreateAPIView):
    queryset = Tag.objects.all()
    serializer_class = TagSerializer
    permission_classes = [IsAuthenticated]

class TagDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Tag.objects.all()
    serializer_class = TagSerializer
    permission_classes = [IsAuthenticated]

class BenefitListView(generics.ListCreateAPIView):
    queryset = Benefit.objects.all()
    serializer_class = BenefitSerializer
    permission_classes = [IsAuthenticated]

class BenefitDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Benefit.objects.all()
    serializer_class = BenefitSerializer
    permission_classes = [IsAuthenticated]

class ProductListView(generics.ListCreateAPIView):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer
    permission_classes = [AllowAny]

class ProductDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer
    permission_classes = [AllowAny]

class ProductImageListView(generics.ListCreateAPIView):
    queryset = ProductImage.objects.all()
    serializer_class = ProductImageSerializer
    permission_classes = [IsAuthenticated]

class ProductImageDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = ProductImage.objects.all()
    serializer_class = ProductImageSerializer
    permission_classes = [IsAuthenticated]

class CompanyView(generics.RetrieveAPIView):
    queryset = Company.objects.all()
    serializer_class = CompanySerializer
    permission_classes = [AllowAny]
    
    def get_object(self):
        # Return the first (and only) company record
        company = Company.objects.first()
        if not company:
            # Create default company if none exists
            company = Company.objects.create(
                name="Kushnath Ayurveda",
                tagline="THE PURITY OF NATURE"
            )
        return company

class CompanyLogoUploadView(generics.UpdateAPIView):
    queryset = Company.objects.all()
    serializer_class = CompanySerializer
    permission_classes = [AllowAny]
    
    def get_object(self):
        return Company.objects.first()
    
    def update(self, request, *args, **kwargs):
        company = self.get_object()
        if 'logo' in request.FILES:
            company.logo = request.FILES['logo']
            company.save()
            return Response({
                'success': True,
                'message': 'Logo uploaded successfully',
                'logo_url': company.logo.url if company.logo else None
            })
        return Response({
            'success': False,
            'message': 'No logo file provided'
        }, status=400)

def logo_upload_page(request):
    company = Company.objects.first()
    if not company:
        company = Company.objects.create(
            name="Kushnath Ayurveda",
            tagline="THE PURITY OF NATURE"
        )
    return render(request, 'logo_upload.html', {'company': company})

@csrf_exempt
@require_POST
def createshipment(request):
    random_order_number = random.randint(100000, 999999)  # Generate a 6-digit random number
    try:
        data = json.loads(request.body)
    except json.JSONDecodeError:
        return JsonResponse({"error": "Invalid JSON payload"}, status=400)

    try:
        pickup_location = PickupLocation.objects.get(id=data.get("pickup_location_id"))
        return_details = ReturnDetails.objects.get(id=data.get("return_details_id"))
    except PickupLocation.DoesNotExist:
        return JsonResponse({"error": "Invalid pickup location ID"}, status=404)
    except ReturnDetails.DoesNotExist:
        return JsonResponse({"error": "Invalid return details ID"}, status=404)

    # Prepare payload
    payload = {
        "pickup_location": {
            "name": pickup_location.name,
            "add": pickup_location.address,
            "city": pickup_location.city,
            "state": pickup_location.state,
            "pin": pickup_location.pin,
            "phone": pickup_location.phone,
            "country": pickup_location.country,
        },
        "shipments": [
            {
                **shipment,  # Take shipment data from the frontend
                "return_name": return_details.name,
                "return_add": return_details.address,
                "return_city": return_details.city,
                "return_state": return_details.state,
                "return_pin": return_details.pin,
                "return_phone": return_details.phone,
                "return_country": return_details.country,
                "order": str(random_order_number),
            }
            for shipment in data.get("shipments", [])
        ],
    }
    payload_str = f"format=json&data={json.dumps(payload)}"
    url = "https://track.delhivery.com/api/cmu/create.json"
    headers = {
        "Authorization": "Token a021bc57b8afddb9d9e6fe61cd5aa5c75b1a5dd7",
        "Content-Type": "application/json",
    }
    response = requests.post(url, headers=headers, data=payload_str)
    res_json = response.json()

    shipment_status = "Shipment Created" if res_json.get("success") else "Shipment Failed"
    try:
        order = OrderDashboard.objects.get(id=data.get("order_id"))
        order.status = shipment_status
        order.save()
    except OrderDashboard.DoesNotExist:
        pass
    return JsonResponse({"shipment_status": shipment_status, "delhivery_response": res_json})

# Sample JSON for frontend usage
# POST /api/dashboard/createshipment/
# Content-Type: application/json
# {
#   "pickup_location_id": 1,
#   "return_details_id": 1,
#   "order_id": 1,
#   "shipments": [
#     {
#       "name": "Consignee Name",
#       "add": "789 Pine Street",
#       "pin": "67890",
#       "city": "Chicago",
#       "state": "IL",
#       "country": "USA",
#       "phone": "1111111111",
#       "products_desc": "Product 1 x 2, Product 2 x 1",
#       "payment_mode": "COD",
#       "total_amount": "499.00",
#       "quantity": "3",
#       "shipment_width": "10",
#       "shipment_height": "10",
#       "weight": "1",
#       "shipping_mode": "Surface",
#       "address_type": "Home"
#     }
#   ]
# }

@api_view(['POST'])
@permission_classes([AllowAny])
def create_razorpay_order(request):
    """
    Create a Razorpay order
    Expected payload:
    {
        "amount": 50000,  // Amount in paise (500.00 INR)
        "currency": "INR",
        "receipt": "order_receipt_123"
    }
    """
    try:
        data = request.data
        
        # Validate required fields
        amount = data.get('amount')
        currency = data.get('currency', 'INR')
        receipt = data.get('receipt')
        
        if not amount:
            return Response({
                'error': 'Amount is required'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        # Convert amount to paise if it's in rupees
        if isinstance(amount, float) or isinstance(amount, str):
            try:
                amount = int(float(amount) * 100)  # Convert to paise
            except ValueError:
                return Response({
                    'error': 'Invalid amount format'
                }, status=status.HTTP_400_BAD_REQUEST)
        
        # Prepare order data
        order_data = {
            'amount': amount,
            'currency': currency,
        }
        
        if receipt:
            order_data['receipt'] = receipt
        
        # Create order with Razorpay
        razorpay_order = razorpay_client.order.create(data=order_data)
        
        # Save order to database
        db_order = RazorpayOrder.objects.create(
            order_id=razorpay_order['id'],
            amount=amount / 100,  # Store in rupees
            currency=currency,
            receipt=receipt,
            status=razorpay_order['status']
        )
        
        # Return response with explicit test mode information
        response_data = {
            'success': True,
            'order_id': razorpay_order['id'],
            'amount': razorpay_order['amount'],
            'currency': razorpay_order['currency'],
            'receipt': razorpay_order.get('receipt'),
            'status': razorpay_order['status'],
            'key_id': RAZORPAY_KEY_ID,
            'mode': RAZORPAY_MODE,
            'environment': 'test' if 'test' in RAZORPAY_KEY_ID else 'live',
            'checkout_url': 'https://checkout.razorpay.com/v1/checkout.html' if RAZORPAY_MODE == 'test' else 'https://checkout.razorpay.com/v1/checkout.html'
        }
        
        return Response(response_data, status=status.HTTP_201_CREATED)
        
    except Exception as e:
        return Response({
            'error': str(e)
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['GET'])
@permission_classes([AllowAny])
def razorpay_config(request):
    """
    Get Razorpay configuration details for frontend
    """
    config_data = {
        'key_id': RAZORPAY_KEY_ID,
        'mode': RAZORPAY_MODE,
        'environment': 'test' if 'test' in RAZORPAY_KEY_ID else 'live',
        'checkout_url': 'https://checkout.razorpay.com/v1/checkout.html',
        'api_url': 'https://api.razorpay.com/v1/',
        'is_test_mode': RAZORPAY_MODE == 'test'
    }
    
    return Response(config_data)

@api_view(['GET'])
@permission_classes([AllowAny])
def get_razorpay_order(request, order_id):
    """
    Get Razorpay order details
    """
    try:
        order = RazorpayOrder.objects.get(order_id=order_id)
        serializer = RazorpayOrderSerializer(order)
        return Response(serializer.data)
    except RazorpayOrder.DoesNotExist:
        return Response({
            'error': 'Order not found'
        }, status=status.HTTP_404_NOT_FOUND)

@api_view(['POST'])
@permission_classes([AllowAny])
def verify_razorpay_payment(request):
    """
    Verify Razorpay payment signature
    """
    try:
        data = request.data
        razorpay_payment_id = data.get('razorpay_payment_id')
        razorpay_order_id = data.get('razorpay_order_id')
        razorpay_signature = data.get('razorpay_signature')
        
        if not all([razorpay_payment_id, razorpay_order_id, razorpay_signature]):
            return Response({
                'error': 'Missing payment verification parameters'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        # Verify signature
        text = f"{razorpay_order_id}|{razorpay_payment_id}"
        signature = hmac.new(
            RAZORPAY_KEY_SECRET.encode(),
            text.encode(),
            hashlib.sha256
        ).hexdigest()
        
        if signature != razorpay_signature:
            return Response({
                'error': 'Invalid payment signature'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        # Update order status
        try:
            order = RazorpayOrder.objects.get(order_id=razorpay_order_id)
            order.status = 'paid'
            order.save()
        except RazorpayOrder.DoesNotExist:
            pass
        
        return Response({
            'success': True,
            'message': 'Payment verified successfully'
        })
        
    except Exception as e:
        return Response({
            'error': str(e)
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@csrf_exempt
@api_view(['POST'])
@permission_classes([AllowAny])
def create_order(request):
    """
    Create a new order (both COD and Razorpay)
    """
    try:
        serializer = CreateOrderSerializer(data=request.data)
        if serializer.is_valid():
            order = serializer.save()
            
            # Set payment status based on payment method
            if order.payment_method == 'cod':
                order.payment_status = 'pending'
                order.order_status = 'confirmed'  # COD orders are confirmed immediately
            elif order.payment_method == 'razorpay':
                order.payment_status = 'pending'
                order.order_status = 'pending'  # Razorpay orders wait for payment confirmation
            
            order.save()
            
            # Update payment transaction status
            transaction = order.transactions.first()
            if transaction:
                transaction.status = 'pending'
                transaction.save()
            
            return Response({
                'success': True,
                'message': 'Order created successfully',
                'order_id': order.id,
                'order_number': order.order_number,
                'payment_status': order.payment_status,
                'order_status': order.order_status
            }, status=status.HTTP_201_CREATED)
        else:
            return Response({
                'success': False,
                'message': 'Invalid order data',
                'errors': serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)
            
    except Exception as e:
        print(f"Error creating order: {str(e)}")
        return Response({
            'success': False,
            'message': f'Failed to create order: {str(e)}'
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['GET'])
@permission_classes([AllowAny])
def get_order_details(request, order_id):
    """
    Get order details by order ID
    """
    try:
        order = CustomerOrder.objects.get(id=order_id)
        serializer = CustomerOrderSerializer(order)
        return Response({
            'success': True,
            'order': serializer.data
        })
    except CustomerOrder.DoesNotExist:
        return Response({
            'success': False,
            'message': 'Order not found'
        }, status=status.HTTP_404_NOT_FOUND)
    except Exception as e:
        return Response({
            'success': False,
            'message': f'Error retrieving order: {str(e)}'
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['POST'])
@permission_classes([AllowAny])
def update_payment_status(request, order_id):
    """
    Update payment status for an order
    """
    try:
        order = CustomerOrder.objects.get(id=order_id)
        serializer = UpdatePaymentStatusSerializer(order, data=request.data, partial=True)
        
        if serializer.is_valid():
            # Update payment status
            if 'payment_status' in serializer.validated_data:
                new_payment_status = serializer.validated_data['payment_status']
                order.payment_status = new_payment_status
                
                # Update order status based on payment status
                if new_payment_status == 'completed':
                    order.order_status = 'confirmed'
                    order.payment_date = datetime.now()
                elif new_payment_status == 'failed':
                    order.order_status = 'cancelled'
                
                order.save()
            
            # Update payment transaction
            transaction = order.transactions.first()
            if transaction:
                if 'payment_status' in serializer.validated_data:
                    new_status = 'completed' if serializer.validated_data['payment_status'] == 'completed' else 'pending'
                    transaction.status = new_status
                    transaction.gateway_response = request.data
                    transaction.save()
            
            return Response({
                'success': True,
                'message': 'Payment status updated successfully',
                'order_id': order.id,
                'payment_status': order.payment_status,
                'order_status': order.order_status
            })
        else:
            return Response({
                'success': False,
                'message': 'Invalid data',
                'errors': serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)
            
    except CustomerOrder.DoesNotExist:
        return Response({
            'success': False,
            'message': 'Order not found'
        }, status=status.HTTP_404_NOT_FOUND)
    except Exception as e:
        return Response({
            'success': False,
            'message': f'Error updating payment status: {str(e)}'
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['PATCH'])
@permission_classes([AllowAny])
def update_order_status(request, order_id):
    """
    Update order status (PATCH method for dashboard)
    """
    try:
        order = CustomerOrder.objects.get(id=order_id)
        
        # Update order status if provided
        if 'order_status' in request.data:
            new_order_status = request.data['order_status']
            order.order_status = new_order_status
            order.save()
            
            return Response({
                'success': True,
                'message': f'Order status updated to {new_order_status}',
                'order_id': order.id,
                'order_status': order.order_status
            })
        else:
            return Response({
                'success': False,
                'message': 'No order_status provided'
            }, status=status.HTTP_400_BAD_REQUEST)
            
    except CustomerOrder.DoesNotExist:
        return Response({
            'success': False,
            'message': 'Order not found'
        }, status=status.HTTP_404_NOT_FOUND)
    except Exception as e:
        return Response({
            'success': False,
            'message': f'Error updating order status: {str(e)}'
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

def test_template(request):
    """Simple test view to verify templates are working"""
    return render(request, 'razorpay_payment.html', {
        'order_data': {
            'amount': '150.00',
            'customer_name': 'Test User',
            'customer_phone': '+91 98765 43210',
            'delivery_address': 'Test Address',
            'delivery_city': 'Test City',
            'delivery_state': 'Test State',
            'delivery_pincode': '123456'
        }
    })

def razorpay_payment_page(request):
    """Render the Razorpay payment page with order data from GET parameters"""
    try:
        # Get order data from GET parameters
        amount = request.GET.get('amount')
        customer_name = request.GET.get('customer_name', '')
        customer_email = request.GET.get('customer_email', '')
        customer_phone = request.GET.get('customer_phone', '')
        delivery_address = request.GET.get('delivery_address', '')
        delivery_city = request.GET.get('delivery_city', '')
        delivery_state = request.GET.get('delivery_state', '')
        delivery_pincode = request.GET.get('delivery_pincode', '')
        order_id = request.GET.get('order_id', '')
        order_number = request.GET.get('order_number', '')
        
        # Validate required fields
        if not amount or not customer_name or not customer_phone:
            return render(request, 'razorpay_payment.html', {
                'error': 'Missing required order information. Please return to checkout and try again.'
            })
        
        # Validate amount
        try:
            amount_float = float(amount)
            if amount_float < 1.00:
                return render(request, 'razorpay_payment.html', {
                    'error': 'Order amount must be at least ₹1.00'
                })
        except ValueError:
            return render(request, 'razorpay_payment.html', {
                'error': 'Invalid amount format'
            })
        
        # Prepare order data for template
        order_data = {
            'amount': amount,
            'customer_name': customer_name,
            'customer_email': customer_email,
            'customer_phone': customer_phone,
            'delivery_address': delivery_address,
            'delivery_city': delivery_city,
            'delivery_state': delivery_state,
            'delivery_pincode': delivery_pincode,
            'order_id': order_id,
            'order_number': order_number
        }
        
        return render(request, 'razorpay_payment.html', {
            'order_data': order_data
        })
        
    except Exception as e:
        print(f"Error in razorpay_payment_page: {str(e)}")
        return render(request, 'razorpay_payment.html', {
            'error': 'An error occurred while loading the payment page. Please try again.'
        })

def checkout_success(request):
    """Render the checkout success page"""
    payment_id = request.GET.get('payment_id', '')
    order_id = request.GET.get('order_id', '')
    amount = request.GET.get('amount', '')
    
    context = {
        'payment_id': payment_id,
        'order_id': order_id,
        'amount': amount,
        'payment_date': datetime.now().strftime('%B %d, %Y at %I:%M %p')
    }
    
    return render(request, 'checkout_success.html', context)

def order_dashboard(request):
    """
    Professional Order Dashboard - Admin Only
    """
    try:
        # Get all orders with related data
        orders = CustomerOrder.objects.select_related().prefetch_related('items', 'transactions').all()
        
        # Get summary statistics
        total_orders = orders.count()
        pending_payments = orders.filter(payment_status='pending').count()
        completed_payments = orders.filter(payment_status='completed').count()
        cod_orders = orders.filter(payment_method='cod').count()
        razorpay_orders = orders.filter(payment_method='razorpay').count()
        
        # Get recent orders
        recent_orders = orders.order_by('-created_at')[:10]
        
        # Get orders by status
        orders_by_status = {
            'pending': orders.filter(order_status='pending').count(),
            'confirmed': orders.filter(order_status='confirmed').count(),
            'processing': orders.filter(order_status='processing').count(),
            'shipped': orders.filter(order_status='shipped').count(),
            'delivered': orders.filter(order_status='delivered').count(),
        }
        
        # Get orders by payment status
        orders_by_payment = {
            'pending': orders.filter(payment_status='pending').count(),
            'completed': orders.filter(payment_status='completed').count(),
            'failed': orders.filter(payment_status='failed').count(),
        }
        
        # Calculate total revenue
        total_revenue = sum(order.final_total for order in orders if order.payment_status == 'completed')
        
        # Get total items sold
        total_items_sold = sum(sum(item.quantity for item in order.items.all()) for order in orders)
        
        context = {
            'total_orders': total_orders,
            'pending_payments': pending_payments,
            'completed_payments': completed_payments,
            'cod_orders': cod_orders,
            'razorpay_orders': razorpay_orders,
            'total_revenue': total_revenue,
            'total_items_sold': total_items_sold,
            'recent_orders': recent_orders,
            'orders_by_status': orders_by_status,
            'orders_by_payment': orders_by_payment,
            'all_orders': orders,
        }
        
        return render(request, 'dashboard/order_dashboard.html', context)
        
    except Exception as e:
        print(f"Error loading dashboard: {str(e)}")
        return render(request, 'dashboard/order_dashboard.html', {
            'error': f'Error loading dashboard: {str(e)}'
        })
@api_view(['GET'])
@permission_classes([AllowAny])
def get_customer_orders(request):
    """
    Get orders for a specific customer by mobile number
    """
    try:
        # Get customer mobile from query parameters
        customer_mobile = request.GET.get('customer_mobile')
        
        print(f"🔍 DEBUG: get_customer_orders called with mobile: '{customer_mobile}'")
        print(f"🔍 DEBUG: Request method: {request.method}")
        print(f"🔍 DEBUG: Request GET params: {dict(request.GET)}")
        
        if not customer_mobile:
            print("❌ DEBUG: No customer mobile provided")
            return Response({
                'success': False,
                'message': 'Customer mobile number is required'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        # Normalize phone number (remove +91, spaces, etc.)
        customer_mobile = customer_mobile.replace('+91', '').replace(' ', '').replace('-', '').replace('(', '').replace(')', '')
        print(f"🔍 DEBUG: Normalized phone number: '{customer_mobile}'")
        
        print(f"🔍 DEBUG: Searching for orders with phone: '{customer_mobile}'")
        
        # Debug: Check all orders in database
        all_orders = CustomerOrder.objects.all()
        print(f"🔍 DEBUG: Total orders in database: {all_orders.count()}")
        for order in all_orders[:5]:  # Show first 5 orders
            print(f"🔍 DEBUG: Order {order.id}: phone='{order.customer_phone}', name='{order.customer_name}'")
            # Also show normalized version of stored phone
            normalized_stored = order.customer_phone.replace('+91', '').replace(' ', '').replace('-', '').replace('(', '').replace(')', '')
            print(f"🔍 DEBUG: Order {order.id}: normalized stored phone='{normalized_stored}'")
        
        # Try to find orders with exact match first
        orders = CustomerOrder.objects.filter(
            customer_phone=customer_mobile
        ).select_related().prefetch_related('items', 'transactions').order_by('-created_at')
        
        # If no exact match, try with +91 prefix
        if not orders.exists():
            print(f"🔍 DEBUG: No exact match found, trying with +91 prefix...")
            orders = CustomerOrder.objects.filter(
                customer_phone=f"+91{customer_mobile}"
            ).select_related().prefetch_related('items', 'transactions').order_by('-created_at')
        
        # If still no match, try without +91 prefix
        if not orders.exists():
            print(f"🔍 DEBUG: No +91 prefix match found, trying without prefix...")
            orders = CustomerOrder.objects.filter(
                customer_phone__endswith=customer_mobile
        ).select_related().prefetch_related('items', 'transactions').order_by('-created_at')
        
        print(f"🔍 DEBUG: Query result count: {orders.count()}")
        
        if not orders.exists():
            print("❌ DEBUG: No orders found in database")
            return Response({
                'success': True,
                'orders': [],
                'message': 'No orders found for this customer'
            })
        
        print(f"✅ DEBUG: Found {orders.count()} orders, serializing...")
        
        # Serialize orders with items and transactions
        orders_data = []
        for order in orders:
            order_data = {
                'id': order.id,
                'order_number': order.order_number,
                'customer_name': order.customer_name,
                'customer_email': order.customer_email,
                'customer_mobile': order.customer_phone,
                'delivery_address': order.delivery_address,
                'delivery_city': order.delivery_city,
                'delivery_state': order.delivery_state,
                'delivery_pincode': order.delivery_pincode,
                'delivery_country': order.delivery_country,
                'payment_method': order.payment_method,
                'payment_status': order.payment_status,
                'order_status': order.order_status,
                'subtotal': float(order.subtotal),
                'shipping_cost': float(order.shipping_cost),
                'total_savings': float(order.total_savings),
                'final_total': float(order.final_total),
                'notes': order.notes,
                'created_at': order.created_at.isoformat(),
                'updated_at': order.updated_at.isoformat(),
                'items': [],
                'transactions': []
            }
            
            # Add order items
            for item in order.items.all():
                item_data = {
                    'id': item.id,
                    'product_name': item.product_name,
                    'product_image': item.product_image,
                    'quantity': item.quantity,
                    'unit_price': float(item.unit_price),
                    'total_price': float(item.total_price)
                }
                order_data['items'].append(item_data)
            
            # Add payment transactions
            for transaction in order.transactions.all():
                transaction_data = {
                    'id': transaction.id,
                    'transaction_id': transaction.transaction_id,
                    'amount': float(transaction.amount),
                    'currency': transaction.currency,
                    'status': transaction.status,
                    'payment_method': transaction.payment_method,
                    'gateway_response': transaction.gateway_response,
                    'created_at': transaction.created_at.isoformat()
                }
                order_data['transactions'].append(transaction_data)
            
            orders_data.append(order_data)
        
        print(f"✅ DEBUG: Successfully serialized {len(orders_data)} orders")
        
        return Response({
            'success': True,
            'orders': orders_data,
            'count': len(orders_data)
        })
        
    except Exception as e:
        print(f"❌ DEBUG: Error in get_customer_orders: {str(e)}")
        import traceback
        traceback.print_exc()
        return Response({
            'success': False,
            'message': f'Error fetching orders: {str(e)}'
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


# AI Bot API Endpoints
@api_view(['GET'])
@permission_classes([AllowAny])
def get_health_tags(request):
    """Get all health tags for AI bot"""
    try:
        tags = Tag.objects.all().order_by('name')
        tags_data = []
        
        for tag in tags:
            # Add emoji based on tag name
            emoji = get_tag_emoji(tag.name)
            tags_data.append({
                'id': tag.id,
                'name': tag.name,
                'icon': emoji,
                'description': f'Products for {tag.name.lower()}',
                'keywords': [tag.name.lower()]
            })
        
        return Response({
            'success': True,
            'tags': tags_data
        })
    except Exception as e:
        return Response({
            'success': False,
            'message': f'Error fetching tags: {str(e)}'
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


@api_view(['POST'])
@permission_classes([AllowAny])
def get_ai_recommendations(request):
    """Get product recommendations based on selected health tags"""
    try:
        data = request.data
        tag_ids = data.get('tag_ids', [])
        
        if not tag_ids:
            return Response({
                'success': False,
                'message': 'No tags selected'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        # Get products that have any of the selected tags
        products = Product.objects.filter(
            tags__id__in=tag_ids,
            available=True
        ).distinct().select_related('category').prefetch_related('tags', 'images')
        
        # If no products found with exact tags, try to find related products
        if not products.exists():
            # Get tag names for broader search
            tag_names = list(Tag.objects.filter(id__in=tag_ids).values_list('name', flat=True))
            
            # Search in product names and descriptions
            products = Product.objects.filter(
                Q(name__icontains=tag_names[0]) | 
                Q(description__icontains=tag_names[0]) |
                Q(category__name__icontains=tag_names[0]),
                available=True
            ).distinct().select_related('category').prefetch_related('tags', 'images')
        
        products_data = []
        for product in products[:6]:  # Limit to 6 products
            # Get first image
            first_image = product.images.first()
            image_url = None
            if first_image:
                # Return full URL for the image
                image_url = f"http://127.0.0.1:8000{first_image.image.url}"
            else:
                # Fallback image if no product image
                image_url = "http://127.0.0.1:8000/media/products/default-product.jpg"
            
            products_data.append({
                'id': product.id,
                'name': product.name,
                'price': float(product.price),
                'image': image_url,
                'description': product.description or f'Natural {product.name} for wellness',
                'category': product.category.name,
                'tags': [tag.name for tag in product.tags.all()]
            })
        
        return Response({
            'success': True,
            'products': products_data,
            'count': len(products_data)
        })
    except Exception as e:
        return Response({
            'success': False,
            'message': f'Error getting recommendations: {str(e)}'
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


def get_tag_emoji(tag_name):
    """Get appropriate emoji for health tag"""
    emoji_map = {
        'diabetes': '🩸',
        'high bp': '❤️',
        'hypertension': '❤️',
        'joint pain': '🦴',
        'arthritis': '🦴',
        'stress': '😤',
        'sleep': '😴',
        'energy': '⚡',
        'skin care': '🧴',
        'skin': '🧴',
        'weight': '⚖️',
        'breathing': '🫁',
        'respiratory': '🫁',
        'digestion': '🫃',
        'digestive': '🫃',
        'immunity': '🛡️',
        'immune': '🛡️',
        'heart': '❤️',
        'liver': '🫁',
        'kidney': '🫁',
        'brain': '🧠',
        'bones': '🦴',
        'muscles': '💪',
        'hair': '💇',
        'eyes': '👁️',
        'teeth': '🦷',
        'hair care': '💇'
    }
    
    # Try exact match first
    if tag_name.lower() in emoji_map:
        return emoji_map[tag_name.lower()]
    
    # Try partial matches
    for key, emoji in emoji_map.items():
        if key in tag_name.lower() or tag_name.lower() in key:
            return emoji
    
    # Default emoji
    return '🌿'
