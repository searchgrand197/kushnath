#!/usr/bin/env python
import os
import sys
import django

# Add the project directory to the Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Set up Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'kushnath_dashboard.settings')
django.setup()

from django.contrib.auth.models import User
from customer.models import Customer

def create_test_user():
    print("🔧 Creating test user for orders...")
    print("=" * 50)
    
    # Check if user already exists
    username = "+918181818181"
    
    try:
        # Create Django user
        user, created = User.objects.get_or_create(
            username=username,
        defaults={
                'first_name': 'Shubham',
                'last_name': 'Garg',
                'email': 'shubham@example.com',
                'is_active': True
            }
        )
        
    if created:
            user.set_password(username)  # Set password same as username
            user.save()
            print(f"✅ Created new user: {username}")
        else:
            print(f"✅ User already exists: {username}")
        
        # Create or update customer profile
        customer, customer_created = Customer.objects.get_or_create(
            user=user,
            defaults={
                'name': 'Shubham Garg',
                'email': 'shubham@example.com'
            }
        )
        
        if customer_created:
            print(f"✅ Created customer profile for: {customer.name}")
        else:
            print(f"✅ Customer profile already exists for: {customer.name}")
        
        print(f"\n📱 Login Credentials:")
        print(f"   Phone: {username}")
        print(f"   Password: {username}")
        print(f"\n🔗 You can now login to the frontend with these credentials")
        print(f"   and should see the orders for this phone number.")
        
    except Exception as e:
        print(f"❌ Error creating user: {e}")

if __name__ == "__main__":
    create_test_user() 