from django.urls import path
from . import views

urlpatterns = [
    # Categories
    path('categories/', views.CategoryListView.as_view(), name='category-list'),
    path('categories/<int:pk>/', views.CategoryDetailView.as_view(), name='category-detail'),
    
    # Tags
    path('tags/', views.TagListView.as_view(), name='tag-list'),
    path('tags/<int:pk>/', views.TagDetailView.as_view(), name='tag-detail'),
    
    # Benefits
    path('benefits/', views.BenefitListView.as_view(), name='benefit-list'),
    path('benefits/<int:pk>/', views.BenefitDetailView.as_view(), name='benefit-detail'),
    
    # Products
    path('products/', views.ProductListView.as_view(), name='product-list'),
    path('products/<int:pk>/', views.ProductDetailView.as_view(), name='product-detail'),
    
    # Product Images
    path('product-images/', views.ProductImageListView.as_view(), name='product-image-list'),
    path('product-images/<int:pk>/', views.ProductImageDetailView.as_view(), name='product-image-detail'),
    path('createshipment/', views.createshipment, name='create-shipment'),
    
    # Razorpay endpoints
    path('rz/orderid/', views.create_razorpay_order, name='create-razorpay-order'),
    path('rz/orderid/<str:order_id>/', views.get_razorpay_order, name='get-razorpay-order'),
    path('rz/verify-payment/', views.verify_razorpay_payment, name='verify-razorpay-payment'),
    path('rz/config/', views.razorpay_config, name='razorpay-config'),
    path('rz/payment-page/', views.razorpay_payment_page, name='razorpay-payment-page'),
    path('rz/test-template/', views.test_template, name='test-template'),
    path('checkout-success/', views.checkout_success, name='checkout-success'),
    
    # Order Management endpoints
    path('order-management/create/', views.create_order, name='create-order'),
    path('order-management/<int:order_id>/', views.get_order_details, name='get-order-details'),
    path('order-management/<int:order_id>/payment-status/', views.update_payment_status, name='update-payment-status'),
    path('order-management/<int:order_id>/order-status/', views.update_order_status, name='update-order-status'),
    
    # Customer Orders endpoint
    path('my-orders/', views.get_customer_orders, name='get-customer-orders'),
    
    # Company Information
    path('company/', views.CompanyView.as_view(), name='company-info'),
    path('company/logo/', views.CompanyLogoUploadView.as_view(), name='company-logo-upload'),
    path('company/upload/', views.logo_upload_page, name='logo-upload-page'),
    
    # Professional Order Dashboard
    path('dashboard/', views.order_dashboard, name='order-dashboard'),
    
    # AI Bot endpoints
    path('ai/health-tags/', views.get_health_tags, name='get-health-tags'),
    path('ai/recommendations/', views.get_ai_recommendations, name='get-ai-recommendations'),
] 