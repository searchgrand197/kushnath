"""
URL configuration for kushnath_dashboard project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.contrib import admin
from django.urls import path, include, re_path
from django.conf import settings
from django.conf.urls.static import static
from rest_framework_simplejwt.views import TokenRefreshView
from dashboard import views as dashboard_views
from . import views

urlpatterns = [
    path("admin/", admin.site.urls),
    path('api/', include('cart.urls')),
    path('api/', include('advertisement.urls')),
    path('api/', include('authentication.urls')),
    path('api/', include('customer.urls')),
    path('api/', include('dashboard.urls')),
    path('api/', include('orders.urls')),
    path('api/coupon/', include('coupon.urls')),
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    
    # AI Bot endpoints (temporary direct inclusion)
    path('api/dashboard/ai/health-tags/', dashboard_views.get_health_tags, name='get-health-tags'),
    path('api/dashboard/ai/recommendations/', dashboard_views.get_ai_recommendations, name='get-ai-recommendations'),
    
    # CORS test endpoint
    path('api/cors-test/', views.cors_test_view, name='cors-test'),
]

# Serve static files from build directory specifically
from django.views.static import serve

# Always serve media files FIRST (both in development and production)
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

# Then serve static files from build directory
urlpatterns += [
    # Serve assets directory files
    re_path(r'^assets/(?P<path>.*)$', serve, {'document_root': settings.BASE_DIR / 'build' / 'assets'}),
    # Serve other static files from build directory
    re_path(r'^(?P<path>.*\.(css|js|png|jpg|jpeg|gif|svg|ico|woff|woff2|ttf|eot))$', serve, {'document_root': settings.BASE_DIR / 'build'}),
    # Serve vite.svg specifically
    re_path(r'^vite\.svg$', serve, {'document_root': settings.BASE_DIR / 'build', 'path': 'vite.svg'}),
    # Catch-all route for React app (must be last)
    re_path(r'^(?!api/).*$', views.serve_react_app, name='react_app'),
]

if settings.DEBUG:
    # Additional debug-only static file serving
    pass
